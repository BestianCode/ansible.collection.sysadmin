# Ansible Collection for FreeBSD and Debian(Ubuntu)

This collection provides a set of Ansible roles designed for configuring and managing Linux servers. While the primary focus is on Debian(Ubuntu) distribution, these roles may not be applicable to other Linux distributions.

In addition to Linux, these roles are being adapted to manage FreeBSD servers, because I still use FreeBSD and there are not so much roles for it in the world.
